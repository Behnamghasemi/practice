<div class="nav">
    <div class="sb-sidenav-menu-heading">Core</div>
    <a class="nav-link" href="dashboard.php">
        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
        Dashboard
    </a>
    <a class="nav-link" href="dashboard.php?page=users">
        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
        Users
    </a>
    <a class="nav-link" href="dashboard.php?page=categories">
        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
        Categories
    </a>
    <a class="nav-link" href="dashboard.php?page=posts">
        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
        Posts
    </a>
</div>